<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="endbox" tilewidth="32" tileheight="36" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="36" source="../sprite/endbox/0.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="36" source="../sprite/endbox/1.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="36" source="../sprite/endbox/2.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="36" source="../sprite/endbox/3.png"/>
 </tile>
</tileset>
