<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects" tilewidth="32" tileheight="64" tilecount="10" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="9">
  <image width="32" height="32" source="../sprite/objects/9.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="32" source="../sprite/objects/10.png"/>
 </tile>
 <tile id="11">
  <image width="32" height="32" source="../sprite/objects/11.png"/>
 </tile>
 <tile id="12">
  <image width="32" height="32" source="../sprite/objects/12.png"/>
 </tile>
 <tile id="13">
  <image width="32" height="32" source="../sprite/objects/13.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="32" source="../sprite/objects/14.png"/>
 </tile>
 <tile id="15">
  <image width="32" height="64" source="../sprite/objects/15.png"/>
 </tile>
 <tile id="16">
  <image width="32" height="32" source="../sprite/objects/16.png"/>
 </tile>
 <tile id="17">
  <image width="32" height="32" source="../sprite/objects/17.png"/>
 </tile>
 <tile id="18">
  <image width="32" height="32" source="../sprite/objects/18.png"/>
 </tile>
</tileset>
