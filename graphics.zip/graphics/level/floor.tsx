<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="floor" tilewidth="32" tileheight="36" tilecount="29" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="../sprite/floor/0.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="../sprite/floor/1.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="../sprite/floor/2.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="32" source="../sprite/floor/3.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="32" source="../sprite/floor/4.png"/>
 </tile>
 <tile id="5">
  <image width="32" height="32" source="../sprite/floor/5.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="../sprite/floor/6.png"/>
 </tile>
 <tile id="7">
  <image width="32" height="32" source="../sprite/floor/7.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="32" source="../sprite/floor/8.png"/>
 </tile>
 <tile id="9">
  <image width="32" height="32" source="../sprite/floor/9.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="32" source="../sprite/floor/10.png"/>
 </tile>
 <tile id="11">
  <image width="32" height="32" source="../sprite/floor/11.png"/>
 </tile>
 <tile id="12">
  <image width="32" height="32" source="../sprite/floor/12.png"/>
 </tile>
 <tile id="13">
  <image width="32" height="32" source="../sprite/floor/13.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="32" source="../sprite/floor/14.png"/>
 </tile>
 <tile id="15">
  <image width="32" height="32" source="../sprite/floor/15.png"/>
 </tile>
 <tile id="16">
  <image width="32" height="32" source="../sprite/floor/16.png"/>
 </tile>
 <tile id="17">
  <image width="32" height="32" source="../sprite/floor/17.png"/>
 </tile>
 <tile id="18">
  <image width="32" height="32" source="../sprite/floor/18.png"/>
 </tile>
 <tile id="19">
  <image width="32" height="32" source="../sprite/floor/19.png"/>
 </tile>
 <tile id="20">
  <image width="32" height="32" source="../sprite/floor/20.png"/>
 </tile>
 <tile id="21">
  <image width="32" height="32" source="../sprite/floor/21.png"/>
 </tile>
 <tile id="22">
  <image width="32" height="32" source="../sprite/floor/22.png"/>
 </tile>
 <tile id="23">
  <image width="32" height="32" source="../sprite/floor/23.png"/>
 </tile>
 <tile id="24">
  <image width="32" height="32" source="../sprite/floor/24.png"/>
 </tile>
 <tile id="25">
  <image width="32" height="32" source="../sprite/floor/25.png"/>
 </tile>
 <tile id="26">
  <image width="18" height="26" source="../sprite/floor/26.png"/>
 </tile>
 <tile id="27">
  <image width="32" height="32" source="../sprite/objects/10.png"/>
 </tile>
 <tile id="28">
  <image width="32" height="36" source="../sprite/floor/28.png"/>
 </tile>
</tileset>
