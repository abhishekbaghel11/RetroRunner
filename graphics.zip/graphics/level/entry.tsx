<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="entry" tilewidth="28" tileheight="64" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="28" height="64" source="../sprite/entry/0Entry1.png"/>
 </tile>
</tileset>
