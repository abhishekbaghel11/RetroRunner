<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ladder" tilewidth="32" tileheight="32" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="../sprite/ladder/0.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="../sprite/ladder/1.png"/>
 </tile>
</tileset>
